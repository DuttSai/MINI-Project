import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { Courses } from '../courses';

@Component({
  selector: 'app-courses-with-json',
  templateUrl: './courses-with-json.component.html',
  styleUrls: ['./courses-with-json.component.css'],
  providers:[CourseService]
})
export class CoursesWithJsonComponent implements OnInit {
  jsonData:any[];
  constructor(private courseservice:CourseService) { }

  ngOnInit() {
    this.courseservice.getCourseData().subscribe((x:any[])=>this.jsonData=x)
  }

}
